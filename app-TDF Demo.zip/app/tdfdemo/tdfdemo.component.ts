import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tdfdemo',
  templateUrl: './tdfdemo.component.html',
  styleUrls: ['./tdfdemo.component.css']
})
export class TDFDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  DisplayOnConsole(formdata:any)
  {
  console.log("::::::::::Employee Details::::::::::")
  console.log("Employee Number = "+formdata.empno);
  console.log("Employee Name = "+formdata.empname);
  console.log("Employee Age = "+formdata.age);
  console.log("====Employee Address Details======= ");
  console.log("House No = "+formdata.AddressDetails.houseno);
  console.log("Building Name = "+formdata.AddressDetails.buildingname);
  console.log("Street = "+formdata.AddressDetails.street);
  console.log("City = "+formdata.AddressDetails.city);
  console.log("PinCode = "+formdata.AddressDetails.pincode)
  console.log("Country = "+formdata.AddressDetails.country);
  console.log("::::::End of Employee Details:::::::")
  }
  
}
